// JobImage.js

import React from 'react';

const FrontPage = () => {
  // Your component logic here
  return(
    <div>
    <center><h1>Job Finder</h1></center>
   <img src="job.jpg" alt="JobImage" width="500px" height="500px"/>
   </div>
   )
};
export default FrontPage;
// No default export
