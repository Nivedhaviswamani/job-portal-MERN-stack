// JobPortalPage.js

import React from 'react';
import './JobPortal.css'
const featuresData = [
  {
    id: 1,
    title: 'Search Jobs',
    description: 'Easily search and find jobs that match your skills and preferences.',
  },
  {
    id: 2,
    title: 'Post a Job',
    description: 'Employers can post job listings to find qualified candidates.',
  },
  {
    id: 3,
    title: 'User Reviews',
    description: 'Read reviews from job seekers and employers about their experiences.',
  },
];

const reviewsData = [
  {
    id: 1,
    author: 'John Doe',
    role: 'Job Seeker',
    review: 'This platform helped me find my dream job. Highly recommended!',
  },
  {
    id: 2,
    author: 'Jane Smith',
    role: 'Employer',
    review: 'Great service for posting job listings and finding talented candidates.',
  },
];

const JobPortalPage = () => {
  return (
    <div className="job-portal-page">
      <section className="features-section">
        <h2>Features</h2>
        <ul className="jj">
          {featuresData.map((feature) => (
            <li className="kk" key={feature.id}>
              <h3>{feature.title}</h3>
              <p>{feature.description}</p>
            </li>
          ))}
        </ul>
      </section>

      <section className="reviews-section">
        <h2>Reviews</h2>
        <div>
          {reviewsData.map((review) => (
            <div key={review.id} className="review">
              <p>{review.review}</p>
              <p>
                <strong>{review.author}</strong> - {review.role}
              </p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default JobPortalPage;
