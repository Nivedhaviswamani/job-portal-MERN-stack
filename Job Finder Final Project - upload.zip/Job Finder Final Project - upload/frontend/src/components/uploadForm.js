import React, { Component } from 'react'
//import './uploadForm.css';
export default class UploadForm extends Component {
 
  constructor(props){
    super(props);
    this.state={
        jobTitle:"",
        salary:"",
        vacancies:"",
        experience:"",
        location:"",
       jobDescription:"",
      submitted:false,
      error:false,
    };
    this.handleSubmit=this.handleSubmit.bind(this);
  }
  setError = (e) => {
    this.setState({ error: e });
  }
  
  setSubmitted = (e) => {
    this.setState({ submitted: e});
  }
    handleSubmit=(e)=>{
    e.preventDefault();
   const {jobTitle,
    salary,
    vacancies,
    experience,
    location,
   jobDescription,}=this.state;
    console.log(jobTitle,salary, vacancies, experience,location,jobDescription,);
    if (jobTitle === '' ||salary===''|| vacancies === '' || experience === ''||location===''||jobDescription==='') {
      this.setError(true);
  } else {
      this.setSubmitted(true);
      this.setError(false);
  
    fetch("http://localhost:3000/uploadJob", {
      method: "POST",
      crossDomain: true,
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({
        jobTitle,
         salary,
        vacancies,
        experience,
        location,
         jobDescription,
        
      }),
    })
      .then((res) => res.json())
      .then((data) => {
        console.log(data, "userRegister");
        
      });
    }
    
  }
   successMessage = () => {
    return (
        <div
            className="success"
            style={{
                display: this.state.submitted ? '' : 'none',
            }}>
            <h6> successfully Uploaded!!</h6>
        </div>
    );
};

// Showing error message if error is true
 errorMessage = () => {
    return (
        <div
            className="error"
            style={{
                display: this.state.error ? '' : 'none',
            }}>
            <h6>Please enter all the fields</h6>
        </div>
    );
};
  render() {
    return (
      <form onSubmit={this.handleSubmit}>
        <h3>Upload Job</h3>

        <div className="mb-3">
          <label>Job Title       </label>
          <input
            type="text"
            className="form-control"
            placeholder="Job Title"
            onChange={(e)=>this.setState({jobTitle:e.target.value})}
          />
        </div>

        <div className="mb-3">
          <label>Salary     </label>
          <input type="number" className="form-control" placeholder="salary" 
          onChange={(e)=>this.setState({salary:e.target.value})}
          />
        </div>

        <div className="mb-3">
          <label>Vacancies    </label>
          <input
            type="number"
            className="form-control"
            placeholder="No of Vacancies"
            onChange={(e)=>this.setState({vacancies:e.target.value})}
          />
        </div>

        <div className="mb-3">
          <label>Experience    </label>
          <input
            type="text"
            className="form-control"
            placeholder="years of Experience"
            onChange={(e)=>this.setState({experience:e.target.value})}
          />
        </div>
        <div className="mb-3">
          <label>Location      </label>
          <input
            type="text"
            className="form-control"
            placeholder="Location"
            onChange={(e)=>this.setState({location:e.target.value})}
          />
        </div>
        <div className="mb-3">
          <label>Job Description    </label>
          <input
            type="text"
            className="form-control"
            placeholder="Job Description"
            onChange={(e)=>this.setState({jobDescription:e.target.value})}
          />
        </div>
        
        <div className="d-grid">
          <button type="submit" className="btn btn-primary">
            Upload
          </button>
          <br></br>
          {this.successMessage()}
            {this.errorMessage()}
        </div>
       
      </form>
    )
  }
}
