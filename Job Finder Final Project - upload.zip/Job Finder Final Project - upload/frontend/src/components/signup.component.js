import React, { Component } from 'react'
//import './sign.css'
export default class SignUp extends Component {
 
  constructor(props){
    super(props);
    this.state={
      fname:"",
      lname:"",
      email:"",
      password:"",
      submitted:false,
      error:false,
    };
    this.handleSubmit=this.handleSubmit.bind(this);
  }
  setError = (e) => {
    this.setState({ error: e });
  }
  
  setSubmitted = (e) => {
    this.setState({ submitted: e});
  }
    handleSubmit=(e)=>{
    e.preventDefault();
   const {fname,lname,email,password}=this.state;
    console.log(fname,lname,email,password);
    if (fname === '' ||lname===''|| email === '' || password === '') {
      this.setError(true);
  } else {
      this.setSubmitted(true);
      this.setError(false);
  
    fetch("http://localhost:3000/register", {
      method: "POST",
      crossDomain: true,
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({
        fname,
        email,
        lname,
        password,
        
      }),
    })
      .then((res) => res.json())
      .then((data) => {
        console.log(data, "userRegister");
        
      });
    }
    
  }
   successMessage = () => {
    return (
        <div
            className="success"
            style={{
                display: this.state.submitted ? '' : 'none',
            }}>
            <h6>User {this.state.fname} successfully registered!!</h6>
        </div>
    );
};

// Showing error message if error is true
 errorMessage = () => {
    return (
        <div
            className="error"
            style={{
                display: this.state.error ? '' : 'none',
            }}>
            <h6>Please enter all the fields</h6>
        </div>
    );
};
  render() {
    return (
      <form onSubmit={this.handleSubmit}>
        <h3>Sign Up</h3>

        <div className="mb-3">
          <label>First name</label>
          <input
            type="text"
            className="form-control"
            placeholder="First name"
            onChange={(e)=>this.setState({fname:e.target.value})}
          />
        </div>

        <div className="mb-3">
          <label>Last name</label>
          <input type="text" className="form-control" placeholder="Last name" 
          onChange={(e)=>this.setState({lname:e.target.value})}
          />
        </div>

        <div className="mb-3">
          <label>Email address</label>
          <input
            type="email"
            className="form-control"
            placeholder="Enter email"
            onChange={(e)=>this.setState({email:e.target.value})}
          />
        </div>

        <div className="mb-3">
          <label>Password</label>
          <input
            type="password"
            className="form-control"
            placeholder="Enter password"
            onChange={(e)=>this.setState({password:e.target.value})}
          />
        </div>

        <div className="d-grid">
          <button type="submit" className="btn btn-primary">
            Sign Up
          </button>
          <br></br>
          {this.successMessage()}
            {this.errorMessage()}
        </div>
        <p className="forgot-password text-right">
          Already registered <a href="/sign-in">sign in?</a>
        </p>
      </form>
    )
  }
}
