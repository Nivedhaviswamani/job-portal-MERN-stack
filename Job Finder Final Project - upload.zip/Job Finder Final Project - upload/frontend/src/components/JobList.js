// JobList.js
import React, { useState, useEffect } from 'react';
import "./JobList.css";
//import axios from 'axios';
 // Import the CSS file
const JobList = () => {
  const [jobs, setJobs] = useState([]);

  /*useEffect(() => {
    const fetchData =async () => {
      try {
        const response = await axios.get('http://localhost:3001/jobDetails'); // Replace with your server URL
        setJobs(response.data);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, []
 );*/
 useEffect(() => {
  const fetchData = async () => {
    try {
      const response = await fetch('http://localhost:3001/jobDetails');
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      const data = await response.json();
      console.log(data);
      setJobs(data);
    } catch (error) {
      console.error('Error fetching data:', error);
      
    }
  };

  fetchData();
}, []);

  return (
    <div class="main">
      <h1>Job Details</h1>
      <div className="job-container">
        {jobs.map((job) => (
          <div key={job._id} className="job-box">
            <div className="job-title">{job.jobTitle}</div>
            <div className="job-details">
              <p>Salary: ${job.salary}</p>
              <p>Vacancies: {job.vacancies}</p>
              <p>Experience: {job.experience} years</p>
              <p>Location: {job.location}</p>
              <p>{job.jobDescription}</p>
            </div>
          </div>
        ))} 
      </div>
    </div>
  );
};

export default JobList;
