import React from 'react'
import '../node_modules/bootstrap/dist/css/bootstrap.min.css'
import './App.css'
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom'
import FrontPage from './components/FrontPage'
import Login from './components/login.component'
import SignUp from './components/signup.component'
import UploadJob from './components/uploadForm'
import JobList from './components/JobList'
import JobPortalPage from './components/JobPortalPage'
import About from './components/About'
function App() {
  return (
    <Router>
      <div className="App">
        <nav className="navbar navbar-expand-lg navbar-light fixed-top">
          <div className="container">
            <Link className="navbar-brand" to={'/front-page'}>
              Job Finder
            </Link>
            <div className="collapse navbar-collapse" id="navbarTogglerDemo02">
              <ul className="navbar-nav ml-auto">
                <li className="nav-item">
                  <Link className="nav-link" to={'/sign-in'}>
                    Login
                  </Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to={'/sign-up'}>
                    Sign up
                  </Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to={'/upload-job'}>
                    Post Job
                  </Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to={'/search-job'}>
                     Search Job
                  </Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to={'/job-portal-page'}>
                     Reviews
                  </Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to={'/about'}>
                     About Us
                  </Link>
                </li>
              </ul>
            </div>
          </div>
        </nav>

        <div className="auth-wrapper">
          <div className="auth-inner">
            <Routes>
            <Route path="/front-page" element={<FrontPage />} />
              <Route exact path="/" element={<Login />} />
              <Route path="/sign-in" element={<Login />} />
              <Route path="/sign-up" element={<SignUp />} />
              <Route path="/upload-job" element={<UploadJob />} />
              <Route path="/search-job" element={<JobList />} />
              <Route path="/job-portal-page" element={<JobPortalPage />} />
              <Route path="/about" element={<About />} />


            </Routes>
  
          </div>
        </div>
      </div>
    </Router>
  )
}

export default App
