const express = require('express');
const mongoose = require('mongoose');

const app = express();
const cors=require("cors");
app.use(cors());
app.use(express.json());
app.use(express.static('build'));
// Replace this with your MongoDB connection string
const mongoURI = 'mongodb+srv://vnivedha9:Nivi1801@clusterformern.nzpqsws.mongodb.net/test?retryWrites=true&w=majority';

mongoose.connect(mongoURI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const db = mongoose.connection;

db.on('error', console.error.bind(console, 'MongoDB connection error:'));
db.once('open',async function () {
  console.log('Connected to MongoDB Atlas');

  // Specify the name of the existing collection
  const collectionName = 'jobDetail'; // Replace with your existing collection name

  // Check if the collection exists
  const collections = await mongoose.connection.db.listCollections({ name: collectionName }).toArray();
console.log(collections);
  if (collections.length > 0) {
    // Collection exists, fetch data
    const jobSchema = new mongoose.Schema({
  jobTitle:String,
   salary:Number,
   vacancies:Number,
   experience:Number,
   location:String,
   jobDescription:String, 
    });
  

    // Register the schema and create the model
    const JobDetail = mongoose.model(collectionName, jobSchema);

  
      try {
        const data = await mongoose.connection.db.collection('jobDetail').find().toArray();
        console.log('Data from the existing collection:', data);
        app.listen(3001, () => {
          console.log(`Server is running on http://localhost:3000`);
        });
        console.log("trying");
                app.get('/jobDetails', (req, res) => {
          res.json(data);
        });
  
        // Start the server
        

  // Print each document
  data.forEach((document) => {
    console.log('Data from the existing collection:', document);
    

  });
      } catch (error) {
        console.error('Error fetching data:', error);
      }
      
  } else {
    console.log(`Collection ${collectionName} does not exist.`);
  }

  // Close the connection after checking
  mongoose.connection.close();
});

