const express=require("express");
const app=express();
const mongoose=require("mongoose");
app.use(express.json())
const cors=require("cors");
app.use(cors());
const bcrypt=require("bcryptjs");
const jwt=require("jsonwebtoken");
const JWT_SECRET="scsdeghrr446745(e)gdsc";
const mongoUrl="mongodb+srv://vnivedha9:Nivi1801@clusterformern.nzpqsws.mongodb.net/?retryWrites=true&w=majority";
mongoose.connect(mongoUrl,{
    useNewUrlParser:true
}).then(()=>{console.log("connected to database");})
.catch((e)=>console.log(e));
app.listen(3000,()=>{
    console.log("server started");
});
require("./userDetails");
const User=mongoose.model("UserInfo1");
app.post("/register",async(req,res)=>{
    const {fname,lname,email,password}=req.body;
    const salt=await bcrypt.genSalt(10);
    const encryptedPassword=await bcrypt.hash(password,salt);
    try{
        const oldUser=await User.findOne({email});
        if(oldUser)
        {
           return res.json({error:"user exists"});
        }
            await User.create({
                fname,
                lname,
                email,
                password:encryptedPassword,
            });
            res.send({status:"ok"});
    }
    catch(error){
        res.send({status:"error"});
    }
});
app.post("/login-user",async (req,res)=>{
    const {email,password}=req.body;
    const user=await User.findOne({email});
    if(!user)
    {
        return res.json({error :"user not found"}); 
    }
    if(await bcrypt.compare(password,user.password))
    {
        const token =jwt.sign(user.password,JWT_SECRET);
        if(res.status(201)){
            return res.json({status:"ok",data:token});

        }
        else{
            return res.json({error:"error"});
        }
    }
    res.json({status:"error",error:"Invalid password"});
});
require("./jobDetails");
const job=mongoose.model("jobDetail");
app.post("/uploadJob",async(req,res)=>{
    const {jobTitle, salary,vacancies,experience,location,jobDescription}=req.body;
    try{
            await job.create({
                jobTitle,
                 salary,
                 vacancies,
                 experience,
                 location,
                jobDescription,
            });
            res.send({status:"ok"});
    }
    catch(error){
        res.send({status:"error"});
    }
});
