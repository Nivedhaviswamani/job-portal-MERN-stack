const mongoose=require("mongoose");
const JobDetailSchema=new mongoose.Schema({
   jobTitle:String,
   salary:Number,
   vacancies:Number,
   experience:Number,
   location:String,
   jobDescription:String, 
},
{
  collection:"jobDetail",  
});
mongoose.model("jobDetail",JobDetailSchema);